<?php
// See main file for uninstall hook. We keep data by default to avoid accidental loss.
