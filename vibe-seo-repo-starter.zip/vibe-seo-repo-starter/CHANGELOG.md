## v0.1.3
- Added safe Freemius bootstrap (optional)
- CI starter & release workflow
